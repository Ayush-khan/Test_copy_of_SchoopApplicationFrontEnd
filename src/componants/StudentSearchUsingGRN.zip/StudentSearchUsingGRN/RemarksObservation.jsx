
const RemarksObservation = () => {
  return <div>RemarksObservation</div>;
};

export default RemarksObservation;
