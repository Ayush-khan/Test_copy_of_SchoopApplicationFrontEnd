const ReportCardCertificates = () => {
  return <div>ReportCardCertificates</div>;
};

export default ReportCardCertificates;
