const HealthActivityRecord = () => {
  return <div>HealthActivityRecord</div>;
};

export default HealthActivityRecord;
